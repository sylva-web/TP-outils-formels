public class Specialisation {
    private boolean carteVerif;
    private boolean codeVerif;

    public Specialisation(boolean carteValide, boolean codeCorrect) {
        this.carteVerif = carteValide;
        this.codeVerif = codeCorrect;
    }

    public boolean isCarteVerif() {
        return carteVerif;
    }

    public boolean isCodeVerif() {
        return codeVerif;
    }
}
