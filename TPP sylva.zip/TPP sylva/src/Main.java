import java.util.Scanner;

public class Main {
    private static final int VraiNumCarte = 1809; // Numéro de carte valide
    private static final int VraiCode = 0000; // Code secret valide

    static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        System.out.println("Entrez votre numéro de carte : ");
        int NumCarte = scanner.nextInt();
        System.out.println("Entrez le code secret : ");
        int CodeSecret = scanner.nextInt();

        // Vérification de la validité de la carte et du code
        boolean VerifCode = (VraiCode == CodeSecret);
        boolean VerifCarte = (VraiNumCarte == NumCarte);

        // Création de l'objet Specialisation pour la vérification
        Specialisation S0 = new Specialisation(VerifCarte, VerifCode);

        // Création de l'automate
        Automate A0 = new Automate();
        A0.VerifCarte(S0.isCarteVerif());
        A0.VerifCode(S0.isCodeVerif());

        int compt = 0; // Compteur pour les tentatives incorrectes

        // Gestion des tentatives d'accès
        while (A0.getEtat() == Automate.Etats.AccesRefuse && compt < 3) {

            if (NumCarte == VraiNumCarte && CodeSecret == VraiCode) {
                A0.setEtat(Automate.Etats.AccesAccorde);
                System.out.println("Accès accordé");
            } else {
                System.out.println("Accès refusé");
                System.out.println("Entrez à nouveau votre numéro de carte : ");
                NumCarte = scanner.nextInt();
                System.out.println("Entrez à nouveau votre code secret : ");
                CodeSecret = scanner.nextInt();

                if (NumCarte == VraiNumCarte && CodeSecret == VraiCode) {
                    A0.setEtat(Automate.Etats.AccesAccorde);
                    System.out.println("Accès accordé");
                } else {
                    A0.VerifCarte(S0.isCarteVerif());
                    A0.VerifCode(S0.isCodeVerif());
                    compt++;
                    System.out.println("Tentatives Restantes : " + (3 - compt));

                    if (compt == 3) {
                        System.out.println("Trois tentatives incorrectes. Alarme déclenchée.");
                        try {
                            Thread.sleep(10000); // Attente de 10 secondes
                        } catch (InterruptedException e) {
                            Thread.currentThread().interrupt();
                        }
                        System.out.println("Réinitialisation du système...");
                        // Réinitialisation des variables
                        compt = 0;
                        // Vous pouvez décider ici de redemander à l'utilisateur ou quitter le système
                        System.out.println("Système réinitialisé, veuillez réessayer.");
                    }
                }
            }
        }
    }
}
