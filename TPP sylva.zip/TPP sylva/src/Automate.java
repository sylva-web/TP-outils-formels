public class Automate {

    public enum Etats {
        AttenteCarte,
        VerificationCode,
        AccesAccorde,
        AccesRefuse
    }

    private Etats etatActuel;

    public Automate() {
        this.etatActuel = Etats.AttenteCarte;
    }

    public Etats getEtat() {
        return etatActuel;
    }

    public void setEtat(Etats nouvelEtat) {
        this.etatActuel = nouvelEtat;
    }

    // Vérification de la carte
    public void VerifCarte(boolean carteValide) {
        if (carteValide) {
            this.setEtat(Etats.VerificationCode);
        } else {
            this.setEtat(Etats.AccesRefuse);
        }
    }

    // Vérification du code
    public void VerifCode(boolean codeCorrect) {
        if (codeCorrect) {
            this.setEtat(Etats.AccesAccorde);
        } else {
            this.setEtat(Etats.AccesRefuse);
        }
    }
}
